# 🎮 GfxGamerLab-AxModule

**Real, verified, no-root gaming optimization module for AxManager**

Auto-closes background apps the instant you launch your game · Forces your device's highest refresh rate · Smooths animations · Reverts everything automatically when you're done.

No fake "overclock" claims. No kernel hacks. Just real Android settings, automated.

[![Telegram](https://img.shields.io/badge/Telegram-Join-blue?logo=telegram)](https://t.me/gfxgamerlab)
[![YouTube](https://img.shields.io/badge/YouTube-Subscribe-red?logo=youtube)](https://www.youtube.com/@GfxGamerLab_1)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-Channel-green?logo=whatsapp)](https://whatsapp.com/channel/0029VbB1E5VFsn0o8MNoAp2l)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

Real, ADB-powered gaming optimization module for **AxManager**. No root. No fake claims. Every feature in this module is built on verified, working Android ADB settings — nothing here is placebo.

📲 **Telegram:** https://t.me/gfxgamerlab
▶️ **YouTube:** https://www.youtube.com/@GfxGamerLab_1
💬 **WhatsApp Channel:** https://whatsapp.com/channel/0029VbB1E5VFsn0o8MNoAp2l

Join for updates, new modules, and tutorials!

---

## ⚠️ Read This First — Honesty Matters

This module does **NOT** overclock your CPU/GPU and does **NOT** edit kernel parameters. That is not possible without root, no matter what any app's marketing claims.

What this module **actually** does is apply real Android system settings through AxManager's ADB environment (the same mechanism Android developers use for debugging) — settings that are normally hidden from regular users but are 100% legitimate, Google-documented Android behaviors.

---

## ✨ What This Module Does

| Feature | How | Real Effect |
|---|---|---|
| **Auto Game Detection** | Monitors foreground app every 2 seconds via `dumpsys window` | Knows the instant you open a listed game |
| **Auto-Close Background Apps** | `am force-stop` on every non-whitelisted running app | Frees RAM/CPU the moment your game opens |
| **Refresh Rate Boost** | `settings put system peak_refresh_rate` | Forces your device's highest supported refresh rate while gaming |
| **Smart Animation Scaling (0.5x)** | `settings put global *_animation_scale 0.5` | UI feels snappier without going fully jarring (not 0, by design) |
| **Window Blur/Transparency Off** | `settings put global disable_window_blurs 1` | Reduces GPU compositing overhead |
| **Adaptive Battery Pause** | `settings put global adaptive_battery_management_enabled 0` | Stops Android from throttling apps to save battery while you game |
| **Samsung CPU Responsiveness** | `settings put global sem_enhanced_cpu_responsiveness 1` | Samsung-specific flag for faster CPU ramp-up (no-op on other brands) |
| **Auto-Revert on Exit** | Same settings restored when you leave the game | Battery/animations go back to normal — nothing stays changed permanently |
| **Live Diagnostic Report** | Action button → ping test, RAM, battery temp, current settings | One tap, real numbers, no guessing |

---

## 📲 Installation

### Step 1 — Install AxManager
Get AxManager from its official source (search "AxManager fahrez182 GitHub" or your trusted module repository).

### Step 2 — Activate ADB Environment
1. Open **Settings > About Phone > Build Number**, tap 7 times to unlock Developer Options
2. Go to **Developer Options > Wireless Debugging** → turn ON
3. Open AxManager → follow its pairing flow to activate ADB

### Step 3 — Install This Module
1. Download this repo as a `.zip` (or download the pre-built `gfxgamerlab-module.zip` from Releases)
2. In AxManager, go to **Modules / Plugins → Install from storage**
3. Select the zip → Install → Reboot or restart the service when prompted

### Step 4 — Add Your Games
1. Find your game's package name:
   ```
   adb shell pm list packages | grep -i <game name>
   ```
2. Edit `games.conf` (inside the module folder, or via AxManager's file manager) and add the package name on its own line
3. Restart the module service from AxManager

### Step 5 — Play
Open your game. The module detects it automatically, applies optimizations, and closes background apps. Close the game — everything reverts automatically.

---

## 🔍 Tap "Action" Anytime

From AxManager's module list, tap the **Action** button on GFX Gamer Lab to get a live report: current refresh rate, animation scale, ping to Google DNS, free RAM, and battery temperature — all real-time, real data.

---

## ❓ FAQ

**Q: Will this overclock my CPU?**
No. This is technically impossible without root. This module only changes Android's own exposed settings (refresh rate, animations, background management) — things Android already supports natively.

**Q: Will my low-end device suddenly run any game perfectly?**
No tool can promise that — hardware limits are hardware limits. What this module *can* do is remove software-side waste (background apps, unnecessary animations, throttling) so your device uses what it already has more efficiently.

**Q: Is this safe?**
Yes. Every setting changed here is reversible and is a standard Android Settings API value — the same ones available in Developer Options, just automated. Nothing touches system partitions, bootloader, or kernel.

**Q: Why 0.5x animation scale and not 0?**
Setting animations fully to 0 can make the UI feel broken/jarring on some devices and doesn't meaningfully change in-game performance (games render their own UI, not Android's). 0.5x is the sweet spot used by performance-focused ROMs.

**Q: Does this work on low-end devices?**
Yes — actually the gains are usually more noticeable on low-end/low-RAM devices, since freeing background RAM matters more when you don't have much RAM to begin with.

---

## 🛠️ Files in This Module

```
gfxgamerlab/
├── module.prop      (module metadata - required by AxManager)
├── service.sh       (background monitor - runs continuously)
├── action.sh        (manual diagnostic report - runs on Action tap)
├── uninstall.sh     (reverts all settings - runs on module removal)
└── games.conf       (your list of game package names - EDIT THIS)
```

---

## 🤝 Contributing

Found a setting that genuinely helps and is verifiable? Open a pull request. No placebo features, no unverifiable claims — this project only ships things that are tested and explainable.

## 📜 License

MIT License — free to use, modify, and share.

---

### 🔗 Stay Connected
📲 Telegram: https://t.me/gfxgamerlab
▶️ YouTube: https://www.youtube.com/@GfxGamerLab_1
💬 WhatsApp: https://whatsapp.com/channel/0029VbB1E5VFsn0o8MNoAp2l
